SMODS.ConsumableType {
    key = 'coolswag',
    primary_colour = HEX('004087'),
    secondary_colour = HEX('004087'),
    collection_rows = { 4, 5 },
    shop_rate = 2,
    cards = {
        ['c_imbored_wegacard'] = true,
        ['c_imbored_supersmashbrosmelee'] = true
    },
    loc_txt = {
        name = "coolswag",
        collection = "coolswag cards",
    }
}